sh scripts/test.sh -p python -d cylinders_normal -n test -w model_best
